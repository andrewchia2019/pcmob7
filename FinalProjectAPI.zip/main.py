from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required, JWTManager
from flask_bcrypt import Bcrypt
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config[
    'SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.abspath('./db.sqlite')}"
app.config['JWT_SECRET_KEY'] = 'hello'  # Change this to a secure key
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)
jwt = JWTManager(app)


# Define your models
class Recipe(db.Model):
  id = db.Column(db.Integer, primary_key=True)
  title = db.Column(db.String(80))
  ingredients = db.Column(db.String(400))
  instructions = db.Column(db.String(400))
  likes = db.Column(db.Integer, default=0)
  is_favorite = db.Column(db.Boolean, default=False) 

  def json(self):
    return {
        'id': self.id,
        'title': self.title,
        'ingredients': self.ingredients,
        'instructions': self.instructions,
        'likes': self.likes,
        'is_favorite': self.is_favorite,
    }


# Create tables
with app.app_context():
  db.create_all()


# Homepage route
@app.route('/', methods=['GET', 'POST'])
def index():
  if request.method == "POST":
    return {'about': 'this is an API for a recipe app. Get / to read more.'}
  else:
    return "Welcome to the Recipe API!"


# Create recipe route
@app.route('/recipes/create', methods=['POST'])
def create_recipe():
  json_data = request.get_json()
  title = json_data['title']
  ingredients = json_data['ingredients']
  instructions = json_data['instructions']

  recipe = Recipe(title=title,
                  ingredients=ingredients,
                  instructions=instructions)

  db.session.add(recipe)
  db.session.commit()
  return recipe.json()


# Get recipe route
@app.route('/recipes/<int:id>', methods=['GET'])
def get_recipe(id):
  recipe = Recipe.query.get(id)

  if recipe is None:
    return {"Error": "Recipe does not exist!"}, 404
  else:
    return recipe.json()


# Get all recipes route
@app.route('/recipes', methods=['GET'])
def all_recipes():
  recipes = Recipe.query.all()
  json_recipes = [recipe.json() for recipe in recipes]
  return jsonify(json_recipes)


# Update recipe route
@app.route('/recipes/<int:id>', methods=['PUT'])
def update_recipe(id):
  recipe = Recipe.query.get(id)

  if recipe is None:
    return {"Error": "Recipe does not exist!"}, 404

  json_data = request.get_json()
  if 'title' in json_data:
    recipe.title = json_data['title']
  if 'ingredients' in json_data:
    recipe.ingredients = json_data['ingredients']
  if 'instructions' in json_data:
    recipe.instructions = json_data['instructions']

  db.session.commit()
  return recipe.json()


# Delete recipe route
@app.route('/recipes/<int:id>', methods=['DELETE'])
def delete_recipe(id):
  recipe = Recipe.query.get(id)

  if recipe is None:
    return {"Error": "Recipe does not exist!"}, 404

  db.session.delete(recipe)
  db.session.commit()

  return {"message": "Recipe with id " + str(id) + " has been deleted"}


# Like a post
@app.route('/recipes/<int:id>/like', methods=['POST'])
def like_recipe(id):
  recipe = Recipe.query.get_or_404(id)

  recipe.likes = recipe.likes or 0

  recipe.likes += 1

  db.session.commit()

  return jsonify({'message': 'Recipe liked successfully'})


@app.route('/recipes/<int:id>/toggle-favorite', methods=['POST'])
def toggle_favorite(id):
  recipe = Recipe.query.get_or_404(id)
  recipe.is_favorite = not recipe.is_favorite
  db.session.commit()
  return recipe.json()


@app.route('/favorited-recipes', methods=['GET'])
def favorited_recipes():
  favorited_recipes = Recipe.query.filter_by(is_favorite=True).all()
  json_recipes = [recipe.json() for recipe in favorited_recipes]
  return jsonify(json_recipes)


if __name__ == '__main__':
  app.run(host='0.0.0.0', port=8000, debug=True)
